package com.assignment2.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment2.core.TournamentScheduler;

/**
 * 
 * @author Amit Padole
 *
 */

@RestController
public class Assignment2Controller {
		
		@RequestMapping(value="/schedule/", method = RequestMethod.GET, produces="text/html")
		public String displayMessage(ModelMap model, @RequestParam int numberOfTeams) {
			if(numberOfTeams < 8) {
				return "Invalid request. Number fo teams should be atleast 8.";
			} else if(numberOfTeams > 20) {
				return "Invalid request. Number of teams more than expectation.";
			} else {
				return TournamentScheduler.schedule(numberOfTeams);
			}
			
		}
		
	}
