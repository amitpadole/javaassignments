package com.assignment2.core;

/**
 * 
 * @author Amit Padole
 *
 */
public class TournamentScheduler {
	
	public static String schedule(final int numberOfTeams) {
		int totalMatches = 0;
		
		for(int i = numberOfTeams - 1; i > 0; i--) {
			totalMatches = totalMatches +  i;
		}
		totalMatches += totalMatches;
		//System.out.println("Total matches: " + totalMatches);
		
		int[][] matches = new int[totalMatches][2];
		int matchIndex = 0;
		
		final boolean isInputOdd = (numberOfTeams % 2) != 0;
		final int modifiedNumberOfTeams = (isInputOdd)? numberOfTeams + 1 : numberOfTeams;
		int groupLength = isInputOdd? (numberOfTeams/2) + 1 : numberOfTeams/2;
		int[] group1 = new int[groupLength];
		int[] group2 = new int[groupLength];
		
		// initially populate groups
		for(int i=0; i< group1.length; i++) {
			group1[i] = i + 1;
			group2[i] = modifiedNumberOfTeams - i;
		}
		
		// rounds loop
		for(int i=1; i < numberOfTeams; i++) {
			for(int j=0; j<group1.length; j++){
				if(isInputOdd && ((group1[j] == modifiedNumberOfTeams) || (group2[j] == modifiedNumberOfTeams))) {
					continue;
				}
				matches[matchIndex][0]=group1[j];
				matches[matchIndex][1]=group2[j];
				matchIndex++;
			}
			
			// adjust group1 values
			int newG1ElementStart = (modifiedNumberOfTeams - i) + 1;
			int g1=1;
			for(; g1< groupLength; g1++,newG1ElementStart++) {
				group1[g1] = newG1ElementStart;
				if(newG1ElementStart == modifiedNumberOfTeams) {
					g1++;
					break;
				};
			}
			
			newG1ElementStart = 2;
			for(;g1<groupLength;g1++,newG1ElementStart++) {
				group1[g1] = newG1ElementStart;
			}
			
			// adjust group2 values
			int newG2ElementStart = group2[0] - 1;
			for(int g2=0; g2<groupLength; g2++,newG2ElementStart--) {
				if(newG2ElementStart == 1) {
					newG2ElementStart = modifiedNumberOfTeams;
				}
				group2[g2] = newG2ElementStart;
			}
		}
	
		// Now scheduling reverse of scheduled matches
		for(int i=0; i<matches.length/2; i++, matchIndex++) {
			matches[matchIndex][0]=matches[i][1];
			matches[matchIndex][1]=matches[i][0];
		}
		
		StringBuffer output = new StringBuffer();
		// Schedule
		for(int i=0; i<matches.length/2; i++) {
			output.append("<b>Day #" + (i+1)+ "</b>" + "<br>");
			output.append((2*i + 1) + ". " + "Team " + matches[2*i][0] + " vs " + "Team " + matches[2*i][1] + "<br>");
			output.append((2*i + 2) + ". " + "Team " + matches[2*i+ 1][0] + " vs " + "Team " + matches[2*i + 1][1] + "<br>");
			output.append("<b>======================================================================</b><br>");
		}
		
		return output.toString();
	}
	
	
}
