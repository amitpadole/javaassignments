package com.assignment1.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.assignment1.service.CheckoutService;
import com.assignment1.service.impl.CheckoutServiceImpl;

@Configuration
public class ServiceConfig {

	@Bean
	public CheckoutService checkoutService() {
		return new CheckoutServiceImpl();
	}
}
