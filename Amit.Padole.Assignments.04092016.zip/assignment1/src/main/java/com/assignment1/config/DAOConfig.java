package com.assignment1.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.assignment1.dao.ItemDAO;
import com.assignment1.dao.impl.ItemDAOImpl;

@Configuration
public class DAOConfig {

	@Bean
	public ItemDAO itemDAO() {
		return new ItemDAOImpl();
	}
}
