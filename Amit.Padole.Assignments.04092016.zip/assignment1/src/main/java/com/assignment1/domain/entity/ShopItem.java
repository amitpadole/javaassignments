package com.assignment1.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name="SHOP_ITEMS")
public class ShopItem {
	
	@Id
	@Column(name="ID", nullable = false)
	private String id;
	
	@Column(name="ITEM_NAME")
	private String name;
	
	@Column(name="ITEM_PRICE")
	private Integer price;
	
	@ManyToOne
    @JoinColumn(name = "ITEM_CATEGORY")
	private CategoryMaster category;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public CategoryMaster getCategory() {
		return category;
	}

	public void setCategory(CategoryMaster category) {
		this.category = category;
	}

}
