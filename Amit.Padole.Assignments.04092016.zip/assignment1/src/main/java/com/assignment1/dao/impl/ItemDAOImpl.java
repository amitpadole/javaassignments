package com.assignment1.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.assignment1.dao.ItemDAO;
import com.assignment1.domain.entity.ShopItem;

@Component(value="ItemDAOImpl")
public class ItemDAOImpl implements ItemDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	private Session getSession(){
		 Session session = null;
		 try{
		     session = sessionFactory.getCurrentSession();
		 } 
		 catch(HibernateException hex){
		     // eating the exception since exception is expected at most of the places, and it is harmless
		 }
		 if(session == null){
		     session = sessionFactory.openSession();
		 }
		 return session;
	}
	
	public List<ShopItem> getShopItems(List<String> itemList) {
		if(itemList == null || itemList.isEmpty()) {
			throw new RuntimeException("Item list is null.");
		}
		
		List<ShopItem> shopItems = new ArrayList<ShopItem>();
		Iterator<String> items = itemList.iterator();
		
		do {
			ShopItem shopItem = getShopItemById(items.next());
			shopItems.add(shopItem);
		} while(items.hasNext());
		
		
		//shopItems = getSession().createCriteria(ShopItem.class).list();
		
		return shopItems;
	}

	private ShopItem getShopItemById(String shopItemId) {
		return getSession().get(ShopItem.class, shopItemId);
	}

}
