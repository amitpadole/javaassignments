package com.assignment1.dao;

import java.util.List;

import com.assignment1.domain.entity.ShopItem;

public interface ItemDAO {
	List<ShopItem> getShopItems(List<String> itemList);
}
