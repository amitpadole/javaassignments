package com.assignment1.service;

import java.util.List;

public interface CheckoutService {
	String checkout(List<String> items);
}
