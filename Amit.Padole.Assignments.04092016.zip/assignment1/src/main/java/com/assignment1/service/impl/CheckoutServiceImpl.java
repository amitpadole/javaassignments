package com.assignment1.service.impl;

import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment1.dao.ItemDAO;
import com.assignment1.domain.entity.ShopItem;
import com.assignment1.service.CheckoutService;

@Service
public class CheckoutServiceImpl implements CheckoutService {

	@Autowired
	private ItemDAO itemDAO;
	
	public void setItemDAO(ItemDAO itemDAO) {
		this.itemDAO = itemDAO;
	}
	
	public String checkout(List<String> items) {
		
		if(items == null || items.isEmpty()) {
			return "No items found.";
		}
		else {
			List<ShopItem> shopItems = itemDAO.getShopItems(items);
			if(shopItems == null || shopItems.isEmpty()) {
				return "No items found.";
			}
			else {
				return performBilling(shopItems);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private String performBilling(List<ShopItem> shopItems) {
		Iterator<ShopItem> items = shopItems.iterator();
		
		float totalTax = 0;
		float totalItemPrice = 0;
		JSONObject finalBill = new JSONObject();
		JSONArray jsonItems = new JSONArray();
		do{
			ShopItem item = items.next();
			if(item == null) {
				continue;
			}
			JSONObject jsonItem = new JSONObject();
			jsonItem.put("name", item.getName());
			jsonItem.put("price", item.getPrice());
			jsonItem.put("salestax", item.getCategory().getSalesTax() + "%");
			jsonItems.add(jsonItem);
			totalTax = totalTax + (item.getPrice() * (float)item.getCategory().getSalesTax() / 100);
			totalItemPrice = totalItemPrice + item.getPrice();
		}while(items.hasNext());

		finalBill.put("items", jsonItems);
		finalBill.put("totaltax", totalTax);
		finalBill.put("billamount", totalItemPrice + totalTax);
		
		return finalBill.toJSONString();
	}

}
