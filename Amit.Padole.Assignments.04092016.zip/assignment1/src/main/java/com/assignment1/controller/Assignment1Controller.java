package com.assignment1.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment1.service.CheckoutService;

/**
 * 
 * @author Amit Padole
 *
 */

@RestController
public class Assignment1Controller {
		
		@Autowired
		private CheckoutService checkoutService;
		
		public void setCheckoutService(CheckoutService checkoutService) {
			this.checkoutService = checkoutService;
		}

		@RequestMapping(value="/checkout/", method = RequestMethod.GET, produces="text/json")
		public String displayMessage(ModelMap model, @RequestParam String[] itemCode) {
			return checkoutService.checkout(Arrays.asList(itemCode));
		}
		
	}
